import client from './client';
// import { Habit } from '../../../../HAVEIT_BACKEND/models';

export const getToday = () => client.get('/habit/today', {
  withCredentials: true,
});

export const getList = () => client.get('/habit', {
  withCredentials: true,
});

export const getSetting = () => client.get('/habit/setting', {
  withCredentials: true,
});

export const getHabitNoti = () => client.get('/habit/noti', {
  withCredentials: true,
});

export const getDailyHabitDetail = ({year, month, day}) => client.get(`/habit/daily/${year}/${month}/${day}`, {
  withCredentials: true,
});

export const getDailyOneHabitDetail = ({habitId, year, month, day}) => client.get(`/habit/${habitId}/daily/${year}/${month}/${day}`, {
  withCredentials: true,
});

export const getHabitToday = ({habitId}) => client.get(`/habit/${habitId}/today`, {
  withCredentials: true,
});

export const getNodo = () => client.get(`/habit/today`, {
  withCredentials: true,
});

export const getMonthlyTotalData = ({year, month}) =>
  client.get(`/habit/monthly/${year}/${month}`, {
    withCredentials: true,
});

export const getMonthlyDataDetail = ({habitId, year, month}) => 
  client.get(`/habit/${habitId}/monthly/${year}/${month}`, {
    withCredentials: true,
});

export const getHabitNotiWeek = ({habitId}) => 
  client.get(`/habit/${habitId}/noti/week`, {
    withCredentials: true,
});

export const getCushionDoll = () =>
  client.get('/device/cushion', {
    withCredentials: true,
});
export const getCushionDailyData = ({dollId}) =>
  client.get(`/device/cushion/${dollId}/today`, {
    withCredentials: true,
});

export const getCushionMonthlyData = ({dollId, year, month}) =>
  client.get(`/device/cushion/${dollId}/${year}/${month}`, {
    withCredentials: true,
});

export const getIdData = ({userName}) => 
  client.get(`/user/${userName}`, {
  withCredentials: true,
});

export const getHabitForModify = ({habitId}) =>
  client.get(`/habit/${habitId}/noti`, {
    withCredentials: true,
});

export const deleteHabit = ({ habitId }) => 
  client.delete(`/habit/${habitId}`, {
    withCredentials: true,
});

export const deleteHabitDetail = ({ habitId, notificationId }) =>
  client.delete(`/habit/${habitId}/noti/${notificationId}`, {
    withCredentials: true,
});

export const toggleHabitStatus = ({habitId}) =>
  client.post(`/habit/activate/${habitId}`, {}, {
    withCredentials: true,
});

export const changeHabitName = ({habitName, habitIconId, habitId}) => 
  client.post(`/habit/${habitId}`, {habitName, habitIconId}, {
    withCredentials: true,
  })

export const postHabit = ({ habitName, habitIconId }) =>
  client.post('/habit', { habitName, habitIconId }, {
    withCredentials: true,
});

export const postHabitDetail = ({ habitId, time, weekId, repeat, endTime, dollId }) => 
  client.post(`/habit/${habitId}/noti`, {time, weekId, repeat, endTime, dollId}, {
    withCredentials: true,
});

export const changeDetailInfo = ({dataId}) =>
  client.post(`/habit/daily/${dataId}`, {}, {
    withCredentials: true,
});

export const changeHabitNoti = ({ habitId, habitNotiId, time, weekId, repeat, dollId, endTime }) =>
  client.post(`/habit/${habitId}/noti/${habitNotiId}`, {time, weekId, repeat, dollId, endTime}, {
    withCredentials: true,
});

