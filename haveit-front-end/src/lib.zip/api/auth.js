import client from './client';

// 로그인
export const login = ({ userName, password }) =>
  client.post('/auth/login', { userName, password }, {
    withCredentials: true,
  });

// 회원가입
export const register = ({ userName, password, email, nickName }) =>
  client.post('/auth/signup', { userName, password, email, nickName }, {
    withCredentials: true,
  });

// 로그인 상태 확인
export const check = () => client.get('/auth/check', {
  withCredentials: true,
});

// 로그아웃
export const logout = () => client.get('/auth/logout', {
  withCredentials: true,
});

