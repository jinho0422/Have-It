import axios from 'axios';

const client = axios.create();

// client.defaults.baseURL = 'http://9bac4f91.ngrok.io'
client.defaults.baseURL = 'http://localhost:8001/'

export default client;
