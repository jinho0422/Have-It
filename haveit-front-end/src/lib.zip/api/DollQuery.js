import doll from './Doll';
// 기기등록
export const postmashine = ({ serialNumber, dollName }) =>
  doll.post('/rasp/web_register', { serialNumber, dollName }, {
    withCredentials: true,
  });

export const deleteDoll = ({ dollId }) => 
  doll.delete(`/rasp/` + dollId,  {
    withCredentials: true,
});

export const changeDollStatus = ({dollId}) =>
  doll.get(`/rasp/activate/${dollId}`, {
    withCredentials: true,
});

export const dollSync = ({dollId}) =>
  doll.get(`/rasp/sync/${dollId}`, {
    withCredentials: true,
});